TEST ONLY – never upload these assets into the ORIGINAL LIVE game.
These 10 WebP images are the approved individual historical reconstructions corresponding to their Daily Discovery IDs.
The ZIP includes the exact original selected Rahab and Abigail illustrations, not their rejected revisions.
Extract and use the images inside assets/daily-book.

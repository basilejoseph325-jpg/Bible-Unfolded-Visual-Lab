BIBLE UNFOLDED VISUAL LAB — TEST ONLY
Upload THIS ZIP without extracting to the root of Bible-Unfolded-Visual-Lab repository on main.
Do NOT upload to the protected LIVE Story-Trails repository.
The installed importer verifies checksums, artwork mapping and mobile book browser before publishing.
The David Tears discovery remains unchanged.
